﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Serialization.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using PicsumServer.Models;
using PicsumServer.Services;

namespace PicsumServer.Controllers
{
    [Route("api/[controller]")]
    public class ImagesController : Controller
    {
        private const string ImagesCacheKey = "cache-key";
        private const string LeftImagesCacheKey = "left-cache-key";

        private readonly IMemoryCache _cache;
        private readonly ImagesService _imagesService;

        private List<ImageModel> images = new List<ImageModel>();
        List<ImageModel> leftImages = new List<ImageModel>();
        List<ImageModel> selectedImages = new List<ImageModel>();

        public ImagesController(IMemoryCache cache, ImagesService imagesService)
        {
            _cache = cache;
            _imagesService = imagesService;
        }

        [HttpGet]
        public async Task<IEnumerable<ImageModel>> Images()
        {
            await GetImages();
            _imagesService.GetRandomImages(images, ref leftImages, ref selectedImages);
            _cache.Set(LeftImagesCacheKey, leftImages);
            return selectedImages;

        }

        private async Task GetImages()
        {
            if (_cache.TryGetValue(ImagesCacheKey, out List<ImageModel> storedImages))
            {
                images = storedImages;
                if (_cache.TryGetValue(LeftImagesCacheKey, out List<ImageModel> lefStoredImages))
                {
                    leftImages = lefStoredImages;
                }
            }

            else
            {
                var msg = await _imagesService.GetImagesFromRemoteServer();
                images = JsonConvert.DeserializeObject<List<ImageModel>>(msg);
                _cache.Set(ImagesCacheKey, images);
                leftImages = images.ToList();
            }
        }
    }
}