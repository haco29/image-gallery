import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-fetch-data',
  templateUrl: './fetch-data.component.html',
  styleUrls: ['./fetch-data.component.scss']
})
export class FetchDataComponent implements OnInit, OnDestroy {
  readonly _http: HttpClient;
  readonly _baseUrl: string;

  readonly MAIN_IMAGE_WIDTH = 750;
  readonly MAIN_IMAGE_HEIGHT = 300;
  readonly INTERVAL_TIME = 30000;

  getSubscribtaion: Subscription;
  IntervalId: any;
  images: ImageModel[];
  selectedImageUrl: string;
  mainImageIndex = 0;
  middleIndexSmallImages = 1;
  selectedAuthor = '';

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this._http = http;
    this._baseUrl = baseUrl;
    this.getImagesFromServer();
  }

  private getImagesFromServer() {
    this.getSubscribtaion = this._http
      .get<ImageModel[]>(this._baseUrl + 'api/Images')
      .subscribe(
        result => {
          this.images = result;
          this.selectedAuthor = this.images[this.mainImageIndex].author;
          if (this.images.length > 0) {
            this.selectedImageUrl = this.getImage(
              this.images[this.mainImageIndex].id,
              this.MAIN_IMAGE_WIDTH,
              this.MAIN_IMAGE_HEIGHT
            );
          }
        },
        error => console.error(error)
      );
  }

  prevImage() {
    this.middleIndexSmallImages -= 1;
    this.restartInterval();
  }

  prevIsEnable(): boolean {
    return this.middleIndexSmallImages > 1;
  }

  nextImage() {
    this.middleIndexSmallImages += 1;
    this.restartInterval();
  }

  nextIsEnable(): boolean {
    return this.middleIndexSmallImages < 3;
  }

  getImage(id: string, width: number, height: number): string {
    return 'https://picsum.photos/id/' + id + '/' + width + '/' + height;
  }

  /// Get image index and calcuated if the index
  /// is in range of not more then 1 from middleIndexSmallImages
  isInImageToShow(imageIndex: number) {
    if (Math.abs(this.middleIndexSmallImages - imageIndex) <= 1) {
      return true;
    }
    return false;
  }

  showMainImage(imageIndex: number) {
    this.mainImageIndex = imageIndex;
    this.selectedAuthor = this.images[this.mainImageIndex].author;
    this.selectedImageUrl = this.getImage(
      this.images[this.mainImageIndex].id,
      this.MAIN_IMAGE_WIDTH,
      this.MAIN_IMAGE_HEIGHT
    );
    this.restartInterval();
  }

  restartInterval() {
    if (this.IntervalId) {
      clearInterval(this.IntervalId);
    }
    this.IntervalId = setInterval(() => {
      this.getImagesFromServer();
    }, this.INTERVAL_TIME);
  }

  ngOnInit() {
    this.IntervalId = setInterval(() => {
      this.getImagesFromServer();
    }, this.INTERVAL_TIME);
  }

  ngOnDestroy() {
    if (this.IntervalId) {
      clearInterval(this.IntervalId);
    }
    this.getSubscribtaion.unsubscribe();
  }
}

interface ImageModel {
  id: string;
  author: string;
  width: number;
  height: number;
  url: string;
  download_url: string;
}
