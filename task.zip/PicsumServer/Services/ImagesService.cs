﻿using Newtonsoft.Json;
using PicsumServer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PicsumServer.Services
{
    public class ImagesService
    {
        /// <summary>
        /// Make a get request to picsum api
        /// </summary>
        /// <returns></returns>
        public async Task<string> GetImagesFromRemoteServer()
        {
            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Accept.Clear();
            var stringTask = client.GetStringAsync("https://picsum.photos/v2/list?page=1&limit=100");
            var msg = await stringTask;
            return msg;
        }

        /// <summary>
        /// Get random images from leftImages
        /// LeftImages and selectedImages will be updated
        /// </summary>
        /// <param name="images"></param>
        /// <param name="leftImages"></param>
        /// <param name="selectedImages"></param>
        public void GetRandomImages(List<ImageModel> images, ref List<ImageModel> leftImages, ref List<ImageModel> selectedImages)
        {
            if (leftImages?.Count < 5)
            {
                leftImages = images.ToList();
            }

            var random = new Random();
            for (int i = 0; i < 5; i++)
            {
                int index = random.Next((leftImages.Count));
                selectedImages.Add(leftImages[index]);
                leftImages.Remove(leftImages[index]);
            }
        }
    }
}
