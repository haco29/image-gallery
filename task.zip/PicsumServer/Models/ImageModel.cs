﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace PicsumServer.Models
{
    [Serializable]
    [DataContract]
    public class ImageModel
    {
        [DataMember]
        [JsonProperty("id")]
        public string Id { get; set; }

        [DataMember]
        [JsonProperty("author")]
        public string Author { get; set; }

        [DataMember]
        [JsonProperty("width")]
        public int Width { get; set; }

        [DataMember]
        [JsonProperty("height")]
        public int Height { get; set; }

        [DataMember]
        [JsonProperty("url")]
        public string Url { get; set; }

        [DataMember]
        [JsonProperty("download_url")]
        public string DownloadUrl { get; set; }
    }
}
